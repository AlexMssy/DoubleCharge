﻿/*
 * Initialisation au chargement de la page
 */

//Initialisation de la gestion des événements onClick sur la page
function initialiser() {
    //Création d'un tableau associant l'id d'un élément et la fonction à appeler en cas de clic sur cet élement
    window.evenementsClic = {
        //btn quizz
        'btnAfficherQuizz': afficherQuizz,
        'rep1': repQuizz,
        'rep2': afficherQuestionSuivante,
        'rep3': afficherQuestionSuivante,
        'rep4': afficherQuestionSuivante
    };

    //Ajout d'un écouteur d'événement onClick sur la page
    window.addEventListener('click', gererEvenement, true);

    //Ajout d'un écouteur d'événement onChange sur la page
    window.addEventListener('change', gererEvenement, true);
}

//Gestion des événements onClick de la page
function gererEvenement(evenement) {
    //Récupère l'id de l'élément sur lequel l'utilisateur a cliqué
    var targetID = evenement.target.id;

    //Récupère le type de l'événement
    var eventType = evenement.type;

    if (eventType === 'click') {
        //Exécute le gestionnaire d'événement onClick correspondant à l'élément cible
        if (window.evenementsClic[targetID]) {
            window.evenementsClic[targetID](evenement);
        }
    }
    else if (eventType === 'change') {
        //Exécute le gestionnaire d'événement onClick correspondant à l'élément cible
        if (window.evenementsChange[targetID]) {
            window.evenementsChange[targetID](evenement);
        }
    }
}

//Lie la fonction initialiser au gestionnaire d'événément onLoad de la page
window.onload = initialiser;
