﻿"use strict";

var questMax;
var quest;
var point;

function clearQuizz() {
    $('#quizz').val(null).empty();
    $('#quest').val(null).empty();
}

function afficherQuizz() {
    clearQuizz();

    questMax = 0;
    quest = 0;
    point = 0;
    commencerQuizz(quest);
}

function repQuizz() {
    /*
    var val = $('input:button[name=rep]:checked').val();
    if (val == 'rep1') {
        point = point + 1;
        alert('point ->' + point);
    }*/

    point = point + 1;

    afficherQuestionSuivante();
}

function afficherQuestionSuivante() {
    clearQuizz();

    if (questMax - 1 == quest) {
        quizzFinis(point);
    }
    else if (questMax -1 > quest) {
        quest = quest + 1;
        commencerQuizz(quest);
    }
}

function commencerQuizz(quest) {

    $.getJSON('json/quizz.json', function (data) {
        questMax = data.qestion.length;

        $('#quizz').append('<div class="quest">' + data.qestion[quest].Question + '</div>');

        
        $('#quizz').append('<form>' + '<br>');
        var a1 = '<input id="rep1" class="buttonMiddle" type="button" value="' + data.qestion[quest].bRep + '">' + '<br>';
        var a2 = '<input id="rep2" class="buttonMiddle" type="button" value="' + data.qestion[quest].mRep1 + '">' + '<br>';
        var a3 = '<input id="rep3" class="buttonMiddle" type="button" value="' + data.qestion[quest].mRep2 + '">' + '<br>';
        var a4 = '<input id="rep4" class="buttonMiddle" type="button" value="' + data.qestion[quest].mRep3 + '">' + '<br>';
        


        var tab = new Array(a1, a2, a3, a4);
        shuffle(tab);
        $('#quizz').append(tab);
        $('#quizz').append('</form>');
        $('#quest').append(quest + 1 + '/' + questMax);
    });
}

function quizzFinis(pt) {
    clearQuizz();

    $('#quizz').append(point + '/' + questMax + '<br >' + '<br >');
    


    switch (pt) {
        case 0: $('#quizz').append("Lamentable!" + '<br>' + '<br>'); break;
        case 1: $('#quizz').append("Null pointeur exeption!" + '<br>' + '<br>'); break;
        case 2: $('#quizz').append("Passable" + '<br>' + '<br>'); break;
        case 3: $('#quizz').append("T'as révisé toi!" + '<br>' + '<br>'); break;
        case 4: $('#quizz').append("Très bien mec!" + '<br>' + '<br>'); break;
    }

    $('#quizz').append('les réponses sont:' + '<br>');

    $.getJSON('json/quizz.json', function (data) {
        $('#quizz').append('<table class="t">');
        for (var i = 0; i < questMax; i++) {

            $('#quizz').append('<tr>' + '<td>'
                + data.qestion[i].Question + '</td>' 
                + '<td>' + data.qestion[i].bRep + '</td>' + '</tr>');
        }
    });
}

function shuffle(a) {
    var j = 0;
    var valI = '';
    var valJ = valI;
    var l = a.length - 1;
    while (l > -1) {
        j = Math.floor(Math.random() * l);
        valI = a[l];
        valJ = a[j];
        a[l] = valJ;
        a[j] = valI;
        l = l - 1;
    }
    return a;
}

function Timer() {
       var dt=new Date()
       window.status=dt.getHours()+":"+dt.getMinutes()+":"+dt.getSeconds();
       setTimeout("Timer()",1000);
}