﻿"use strict";

var trajet;

function AfficherTrajet() {
    
    //$('#trajetExistant').append('<p>' + trajet + '</p>');
    $.getJSON('json/trajet.json', function (data) {
        var trajet = data.trajet.length;

        for (var i = 0; i < trajet; i++) {
            $('#trajetExistant').append('<h3><p>Trajet: ' + i + '</p>');
            $('#trajetExistant').append('<p>' + data.trajet[i].lieuDepart + '</p>');
            $('#trajetExistant').append('<p>' + data.trajet[i].lieuArrive + '</p>');
            $('#trajetExistant').append('<p>' + data.trajet[i].materiaux + '</p>');
            $('#trajetExistant').append('<p>' + data.trajet[i].transport + '</p></h3>');
        }
    });
}

function AvoirJson() {

    $.getJSON('json/quizz.json', function (data) {
        var questMax = data.qestion.length;

        for (var i = 0; i < questMax; i++) {
            $('#quizz').append('<p>' + data.qestion[i].Question + '</p>');
        }
        console.log(questMax);
    });
}

function CreerTrajet() {
    var lieuDepart = document.getElementById('origin').value
    var lieuArrive = document.getElementById('destination').value
    var materiaux = document.getElementById('materiaux').value
    var benne = document.getElementById('benne').value
    
    trajet = {
        "lieuDepart" : lieuDepart,
        "lieuArrive" : lieuArrive,
        "materiaux" : materiaux,
        "benne" : benne
    };

    console.log(trajet);

    //trajet[2] = materiaux;
    //trajet[3] = benne;

    //$('#trajet').append('<p>' + trajet[0] + '</p>');;
    /*$.getJSON('json/trajet.json', function (data) {
        var json = JSON.stringify("lieuDepart:" + lieuDepart,
                "lieuArrive:" + lieuArrive,
                "materiaux:" + materiaux,
                "transport:" + benne);
    });*/
    
}

        
        